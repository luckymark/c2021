#ifndef PLAYER_H
#define PLAYER_H

sf::Sprite PlayerBasic();
void PlayerSound();
void PlayerMove();
void PlayerAttack();
bool PlayerDefense();
sf::Sprite PlayerBulletBasic();
void BulletMove();
void SPUpWithTime();
void ScoreUpWithTime();

#endif

